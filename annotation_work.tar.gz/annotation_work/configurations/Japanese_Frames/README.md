# Japanese Frames #

Configuration for Japanese frame semantic annotations by Yuichiroh
Matsubayashi Ph.D of the National Institute of Informatics (NII).
