# MUC-6 Information Extraction Configuration #

MUC-6 Information Extraction configuration used for visualising examples from
Chambers and Jurafsky (2011). Not completely in line with the actual MUC-6
format (yet).

http://www.cs.nyu.edu/cs/faculty/grishman/muc6.html
